/*
 File : drugController.js
 The DrugController interact with the current drug to display
 */

'Use Strict';

angular.module('App')

    .controller('DrugController', function($scope, $stateParams) {


    });
