/*
 File : startController.js
 The HomeController interact with the home view
 */

'Use Strict';

angular.module('App')

    .controller('StartController', function($scope) {

    });